const { summarizeText } = require('../services/aiService');
const { isValidText } = require('../utils/validateInput');

exports.processText = (req, res) => {
  const { text } = req.body;

  if (!isValidText(text)) {
    return res.status(400).json({ error: 'Invalid or empty text' });
  }

  const summary = summarizeText(text);

  res.json({
    originalLength: text.length,
    summary
  });
};
