const express = require('express');
const { processText } = require('../controllers/processController');

const router = express.Router();

router.post('/process', processText);

module.exports = router;
