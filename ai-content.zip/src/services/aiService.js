exports.summarizeText = (text) => {
  const sentences = text.split('.');
  return sentences.slice(0, 2).join('.') + '.';
};
