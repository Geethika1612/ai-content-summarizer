const express = require('express');
const processRoutes = require('./routes/processRoutes');

const app = express();

app.use(express.json());
app.use('/api', processRoutes);

app.get('/', (req, res) => {
  res.send('AI Content Summarizer API is running');
});

module.exports = app;
