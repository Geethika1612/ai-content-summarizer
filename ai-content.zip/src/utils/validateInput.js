exports.isValidText = (text) => {
  return typeof text === 'string' && text.trim().length > 20;
};
